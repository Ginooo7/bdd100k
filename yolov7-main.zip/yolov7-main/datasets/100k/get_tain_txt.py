# coding: utf8
import os

path = "D:/Google_download/yolov7-main/datasets/100k/images/val/"

content = []

for root, ds, fs in os.walk(path):
    for f in fs:
        file_name = "/content/yolov7-main/datasets/100k/images/val/" + f
        print(file_name)
        content.append(file_name)
        
with open("val_list.txt",  "w") as f:
    f.write("\n".join(content))
