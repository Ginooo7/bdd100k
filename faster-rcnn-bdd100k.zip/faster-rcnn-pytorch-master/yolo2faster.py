import os
import glob
import cv2

# 文件夹路径
folder_path = 'D:/Google_download/faster-rcnn-pytorch-master/VOCdevkit/VOC2007/Annotations/yolo7_txt/val_txt/'
# 类别文件路径
classes_path = 'D:/Google_download/faster-rcnn-pytorch-master/model_data/voc_classes.txt'

# 读取类别文件
with open(classes_path, 'r') as f:
    classes = f.read().strip().split('\n')

# 获取所有的标注文件
annotation_files = glob.glob(os.path.join(folder_path, '*.txt'))

# 输出文件
output_file = open('val.txt', 'w')

for annotation_file in annotation_files:
    # 获取对应的图像文件
    image_filename = os.path.basename(os.path.splitext(annotation_file)[0]) + '.jpg'
    image_file = os.path.join('D:/Google_download/faster-rcnn-pytorch-master/VOCdevkit/VOC2007/JPEGImages/val/', image_filename)
    image = cv2.imread(image_file)
    h, w = image.shape[:2]

    with open(annotation_file, 'r') as f:
        lines = f.read().strip().split('\n')

    output_line = [image_file]

    for line in lines:
        class_id, x, y, width, height = map(float, line.split())
        class_id = int(class_id)

        # 将归一化的坐标转换为实际坐标
        x = x * w
        y = y * h
        width = width * w
        height = height * h

        # 将中心点坐标和宽高转换为左上角和右下角的坐标
        xmin = int(x - width / 2)
        ymin = int(y - height / 2)
        xmax = int(x + width / 2)
        ymax = int(y + height / 2)

        output_line.append(f"{xmin},{ymin},{xmax},{ymax},{class_id}")

    output_file.write(' '.join(output_line) + '\n')

output_file.close()
