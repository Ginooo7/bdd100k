# 打开文件进行读取
with open('selected_val_images.txt', 'r') as file:
    lines = file.readlines()
    # 处理每一行
    new_lines = [line.strip()[:-4] if line.strip().endswith('.jpg') else line.strip() for line in lines]

# 重新打开文件进行写入
with open('selected_val_images.txt', 'w') as file:
    for line in new_lines:
        file.write(line + '\n')
